TRUNCATE TABLE TALEND_JOBS;

INSERT INTO TALEND_JOBS
(STATUS, SF_ENTITY,JOB_NAME,FILTER_DATE)
SELECT 2 STATUS, FECHAS.SF_ENTITY,JOBS.JOB_NAME,FECHAS.FECHA FROM
(
SELECT 
replace(OBJECT_NAME,'__C') SF_ENTITY,
max(QUERY_END_DATE) FECHA
FROM TSALESFORCE.RJ_HISTORY
WHERE OBJECT_NAME <> 'ORGANIZATION'
GROUP BY OBJECT_NAME
) FECHAS
JOIN
(select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_getAccountData' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccountCadena_VPDVFIM' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccountGrupo_VPDVFIM' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccountPDV_VPDVFIM' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccountUnion_VPDVFIM' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_AgregadoFinanciadoClasicoActual' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_AgregadoFinanciadoTarjetaActual' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_AgregadoOperacionesFinanciadasClasico' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_AgregadoOperacionesFinanciadasTarjeta' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_AgregadoOperacionesRecibidasClasico' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_AgregadoOperacionesRecibidasTarjetas' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_AgregadosCuenta' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_MixClasico' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_MixClasicoCGU' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_OperacionesAseguradas' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_OperacionesPrimaUnica' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_OperacionesRechazadasToCero' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_ProduccionCGU_1' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_ProduccionCGU_2' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_ProduccionCGU_3' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_RecibidoClasicoActual' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_RecibidoTarjetaActual' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setAccount_Salesforce' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setVaccount_Cero' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setVaccount_KYI_1' JOB_NAME FROM DUAL union
select 'ACCOUNT' SF_ENTITY, 'jo_SALESFORCE_setVaccount_KYI_2' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_getAgenciaData' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_FidelizadosCA' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_MixCA' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_Prima' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_ProdMes_Agregados_CA' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_SF' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_SegmentoCA_2' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_SegmentoCA_4' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_SegmentoCA_6' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_SegmentoCA_8' JOB_NAME FROM DUAL union
select 'AGENCIA' SF_ENTITY, 'jo_SALESFORCE_setAgencia_VPDVFIM' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_getCarteraData' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_FidelizadosCA' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_MixCA' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_Prima' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_ProdMes_Agregados_CA' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_SF' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_SegmentoCA_1' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_SegmentoCA_3' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_SegmentoCA_5' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_SegmentoCA_7' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setCartera_VPDVFIM' JOB_NAME FROM DUAL union
select 'CARTERA' SF_ENTITY, 'jo_SALESFORCE_setVcartera_Cero' JOB_NAME FROM DUAL union
select 'OPERCAMP' SF_ENTITY, 'jo_SALESFORCE_getOperCampData' JOB_NAME FROM DUAL union
select 'OPERCAMP' SF_ENTITY, 'jo_SALESFORCE_setOperCamp_Oportunities' JOB_NAME FROM DUAL union
select 'OPERCAMP' SF_ENTITY, 'jo_SALESFORCE_setOperCamp_SF' JOB_NAME FROM DUAL union
select 'OPPORTUNITY' SF_ENTITY, 'jo_SALESFORCE_getOpportunityData' JOB_NAME FROM DUAL union
select 'OPPORTUNITY' SF_ENTITY, 'jo_SALESFORCE_setOpportunities_Operacciones_Mensual_dia' JOB_NAME FROM DUAL union
select 'OPPORTUNITY' SF_ENTITY, 'jo_SALESFORCE_setOpportunity_Operaciones' JOB_NAME FROM DUAL union
select 'OPPORTUNITY' SF_ENTITY, 'jo_SALESFORCE_setOpportunity_SF' JOB_NAME FROM DUAL union
select 'RED' SF_ENTITY, 'jo_SALESFORCE_getRedData' JOB_NAME FROM DUAL union
select 'RED' SF_ENTITY, 'jo_SALESFORCE_setOpportunities_Borrado_Red' JOB_NAME FROM DUAL union
select 'RED' SF_ENTITY, 'jo_SALESFORCE_setRed_Agencia' JOB_NAME FROM DUAL union
select 'RED' SF_ENTITY, 'jo_SALESFORCE_setRed_SF' JOB_NAME FROM DUAL union
select 'SOCIEDAD' SF_ENTITY, 'jo_SALESFORCE_getSociedadData' JOB_NAME FROM DUAL union
select 'SOCIEDAD' SF_ENTITY, 'jo_SALESFORCE_setSociedad_Agencia' JOB_NAME FROM DUAL union
select 'SOCIEDAD' SF_ENTITY, 'jo_SALESFORCE_setSociedad_SF' JOB_NAME FROM DUAL union
select 'USER' SF_ENTITY, 'jo_SALESFORCE_getUserData' JOB_NAME FROM DUAL
) JOBS
ON
FECHAS.SF_ENTITY = JOBS.SF_ENTITY;
