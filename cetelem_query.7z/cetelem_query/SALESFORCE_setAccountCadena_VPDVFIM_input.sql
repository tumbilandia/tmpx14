SELECT TR.cadena          N_VENDEDOR,
       DECODE(TR.nom_com_cadena,null,'  ',TR.nom_com_cadena)  NOMBRE_CADENA, 
       case when b.ETL_ID is null then 'I' else 'U' end as TIPOREGTALEND
FROM adc400exp.vpdvfim TR LEFT OUTER JOIN TSALESFORCE.TACCOUNT b
ON TO_CHAR(TR.cadena) = b.N_VENDEDOR
WHERE TR.red_pdv in (1,3,4)
AND TO_DATE(TR.FEC_MOD,'DD/MM/YYYY')> TO_DATE('###REPLACE_BY_DATE###', 'DD/MM/YYYY HH24:MI:SS')
GROUP BY TR.cadena, TR.nom_com_cadena, case when b.ETL_ID is null then 'I' else 'U' end
