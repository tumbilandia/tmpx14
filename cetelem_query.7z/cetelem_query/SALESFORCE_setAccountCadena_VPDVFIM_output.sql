INSERT INTO TACCOUNT
      (NAMEX,
       N_VENDEDOR,
       OWNERID,
       CREATEDDATE,
       CREATEDBYID,
       RECORDTYPEID,
       NOMBRE_CADENA,
       DELETE_FLAG )
VALUES (:NOMBRE_CADENA:,
       :N_VENDEDOR:,
       '00520000000otT7AAI',
        SYSDATE,
       '00520000000otT7AAI',
        (select Id
		   from trecordtype
		  where idcetelem='CADENA'
		   and rownum< 2),
        :NOMBRE_CADENA:,
        'I');

UPDATE TACCOUNT
SET SYSTEMMODSTAMP = sysdate,
    NOMBRE_CADENA = :NOMBRE_CADENA:,
    OWNERID = '00520000000otT7AAI',
    Id = Case When Delete_Flag = 'Y'
          Then null
          Else Id
         End,
    DELETE_FLAG = Case When Delete_Flag= 'N'
                   then 'U'
                   else Delete_Flag
                  end
WHERE  N_VENDEDOR= :N_VENDEDOR:
