INSERT INTO TACCOUNT
      (NAMEX,
       SHIPPINGSTREET,
       SHIPPINGCITY,
       SHIPPINGPOSTALCODE,
       BILLINGSTREET,
       BILLINGCITY,
       PHONE,
       FAX,
       NUMBEROFEMPLOYEES,
       OWNERID,
       CREATEDDATE,
       CREATEDBYID,
       LASTMODIFIEDDATE,
       LASTMODIFIEDBYID,
       CIF,
       N_VENDEDOR,
       CUENTA_CORRIENTE_20_DIGITOS,
       N_CONTENCIOSO,
       RAZON_SOCIAL,
       N_RECOBRO,
       N_RIESGO_VIVO_TOTAL,
       SITUACION,
       ZONA,
       SECTOR,
       INDUSTRY,
       N_CARTERA,
       N_AGENCIA,
       ALERTA,
       RED,
       SITUACION_DESDE,
       FECHA_DE_ENTRADA,
       TELEMATICA,
       ULTIMA_FINANCIACION,
       RATING,
       NOMBRE_DE_CADENA,
       NOMBRE_DE_GRUPO,
       NOMBRE_DE_UNION,
       RECORDTYPEID,
       DNIDIRIGENTE,
       NOMBREDIRIGENTE,
       CONTENCIOSOTARJETA,
       RECOBRO_TARJETA,
       RIESGO_TARJETA,
       AGENCIA,
       CARTERA,
       N_CADENA_INT,
       N_GRUPO_INT,
       N_UNION_INT,
       TEMPORAL,
       N_CARTERA_INT,
       SOCIEDAD,
       DELETE_FLAG , SYSTEMMODSTAMP)
VALUES(:NAMEX:,
       :SHIPPINGSTREET:,
       :SHIPPINGCITY:,
       :SHIPPINGPOSTALCODE:,
       :BILLINGSTREET:,
       :BILLINGCITY:,
       :PHONE:,
       :FAX:,
       :NUMBEROFEMPLOYEES:,
       '00520000000otT7AAI',
        SYSDATE,
       '00520000000nO54AAE',
       SYSDATE,
       '00520000000nO54AAE',
       :CIF:,
       :N_VENDEDOR:,
       :CUENTA_CORRIENTE_20_DIGITOS:,
       :N_CONTENCIOSO:,
       :RAZON_SOCIAL:,
       :N_RECOBRO:,
       :N_RIESGO_VIVO_TOTAL:,
       :SITUACION:,
       :ZONA:,
       :SECTOR:,
       (select  value
          from  rj_reference
         where  object_name ='ACCOUNT'
           AND  field_name ='INDUSTRY'
           and  idcetelem= :INDUSTRY:
           and  rownum < 2),
       TRIM(CONCAT( :N_AGENCIA: , :N_CARTERA: )),
       :N_AGENCIA:,
        :ALERTA:,
        :RED:,
        :SITUACION_DESDE: +2/24,
        :FECHA_DE_ENTRADA: +2/24,
        :TELEMATICA:,
        to_Date(decode( :ULTIMA_FINANCIACION: ,'01-01-0001','01-01-2001',
                        :ULTIMA_FINANCIACION: ),'mm-dd-yyyy')  ,
        :RATING:,
        (select id
           from taccount
          where N_VENDEDOR = :NOMBRE_DE_CADENA:
            and recordtypeid='012200000008eM9AAI'
            and delete_flag NOT in ('Y','D')
            AND rownum < 2),
        (select id
           from taccount
          where N_VENDEDOR = :NOMBRE_DE_GRUPO:
            and recordtypeid='012200000008eMAAAY'
            and delete_flag NOT in ('Y','D')
            AND rownum < 2),
        (select id
           from taccount
          where N_VENDEDOR = :NOMBRE_DE_UNION:
           and recordtypeid='012200000008eMEAAY'
           and delete_flag NOT in ('Y','D')
           AND rownum < 2),
        (select id
           from trecordtype
          where idcetelem='PDV'
            and rownum < 2),
        :DNIDIRIGENTE:,
        :NOMBREDIRIGENTE:,
        :CONTENCIOSOTARJETA:,
        :RECOBRO_TARJETA:,
        :RIESGO_TARJETA:,
        (SELECT ID
           FROM TSALESFORCE.TAGENCIA
          WHERE NAMEX = :AGENCIA:
            and red = :RED:
            AND SOCIEDAD = :SOCIEDAD:
            and delete_flag NOT in ('Y','D')),
        (select id
           from tcartera
          where namex = :CARTERA:
            and red = :RED:
            AND SOCIEDAD = :SOCIEDAD:
            and delete_flag NOT in ('Y','D')),
         :N_CADENA_INT:,
         :N_GRUPO_INT:,
         :N_UNION_INT:,
         :TEMPORAL:,
         :N_CARTERA_INT:,
         :SOCIEDAD:,
         'I', SYSDATE );
UPDATE TACCOUNT
SET    SYSTEMMODSTAMP = sysdate,
       NAMEX = :NAMEX:,
       SHIPPINGSTREET = :SHIPPINGSTREET:,
       SHIPPINGCITY   = :SHIPPINGCITY:,
       SHIPPINGPOSTALCODE = :SHIPPINGPOSTALCODE:,
       BILLINGSTREET      = :BILLINGSTREET:,
       BILLINGCITY        = :BILLINGCITY:,
       PHONE = :PHONE:,
       FAX = :FAX:,
       NUMBEROFEMPLOYEES = :NUMBEROFEMPLOYEES:,
       LASTMODIFIEDDATE = SYSDATE,
       LASTMODIFIEDBYID = '00520000000otT7AAI',
       CIF = :CIF:,
       CUENTA_CORRIENTE_20_DIGITOS = :CUENTA_CORRIENTE_20_DIGITOS:,
       N_CONTENCIOSO = :N_CONTENCIOSO:,
       RAZON_SOCIAL = :RAZON_SOCIAL:,
       N_RECOBRO = :N_RECOBRO:,
       N_RIESGO_VIVO_TOTAL = :N_RIESGO_VIVO_TOTAL:,
       SITUACION = :SITUACION:,
       ZONA = :ZONA:,
       SECTOR = :SECTOR:,
       INDUSTRY = (select value
                    from  rj_reference
                    where object_name ='ACCOUNT'
                      AND field_name ='INDUSTRY'
                      and idcetelem= :INDUSTRY:
                      and rownum < 2),
       N_CARTERA = TRIM(CONCAT( :N_AGENCIA: , :N_CARTERA: )),
       N_AGENCIA = :N_AGENCIA:,
       ALERTA = :ALERTA:,
       RED = :RED:,
       SITUACION_DESDE = :SITUACION_DESDE: +2/24,
       FECHA_DE_ENTRADA =  :FECHA_DE_ENTRADA: +2/24 ,
       TELEMATICA = :TELEMATICA:,
       ULTIMA_FINANCIACION = to_Date(decode( :ULTIMA_FINANCIACION: ,'01-01-0001','01-01-2001'
                                           , :ULTIMA_FINANCIACION: ),'mm-dd-yyyy')  ,
       RATING = :RATING:,
       NOMBRE_DE_CADENA = (select id
                           from taccount
                          where N_VENDEDOR = :NOMBRE_DE_CADENA:
                            and recordtypeid='012200000008eM9AAI'
                            and delete_flag NOT in ('Y','D')
                            AND rownum < 2),
       NOMBRE_DE_GRUPO = (select id
                            from taccount
                           where N_VENDEDOR = :NOMBRE_DE_GRUPO:
                             and recordtypeid='012200000008eMAAAY'
                             and delete_flag NOT in ('Y','D')
                             AND rownum < 2),
       NOMBRE_DE_UNION = (select id
                            from taccount
                           where N_VENDEDOR = :NOMBRE_DE_UNION:
                             and recordtypeid='012200000008eMEAAY'
                             and delete_flag NOT in ('Y','D')
                             AND rownum < 2),
       DNIDIRIGENTE = :DNIDIRIGENTE:,
       NOMBREDIRIGENTE = :NOMBREDIRIGENTE:,
       CONTENCIOSOTARJETA =  :CONTENCIOSOTARJETA:,
       RECOBRO_TARJETA =  :RECOBRO_TARJETA:,
       RIESGO_TARJETA =   :RIESGO_TARJETA:,
       AGENCIA      = (SELECT ID
                         FROM TSALESFORCE.TAGENCIA
                        WHERE NAMEX = :AGENCIA:
                          and red = :RED:
                          AND SOCIEDAD = :SOCIEDAD:
                          and delete_flag NOT in ('Y','D') ),
       CARTERA = (select id
                    from tcartera
                   where namex = :CARTERA:
                     and red = :RED:
                     AND SOCIEDAD = :SOCIEDAD:
                     and delete_flag NOT in ('Y','D')),
       N_CADENA_INT  = :N_CADENA_INT:,
       N_GRUPO_INT  = :N_GRUPO_INT:,
       N_UNION_INT  = :N_UNION_INT:,
       OWNERID = '00520000000otT7AAI',
       TEMPORAL = :TEMPORAL:,
       N_CARTERA_INT = :N_CARTERA_INT:,
       SOCIEDAD = :SOCIEDAD:,
DELETE_FLAG = Case When DELETE_FLAG= 'Y' then 'I'
                   When Delete_Flag= 'I' then 'I'
                   When Delete_Flag= 'N' then 'U'
                   else 'U'
              end,
       Id = Case When Delete_Flag = 'Y'
              Then null
              Else Id
            End
WHERE  N_VENDEDOR = :N_VENDEDOR: