SELECT to_char(TR.UNI_ON)             N_VENDEDOR,
       DECODE(TR.nom_com_union,null,'  ',TR.nom_com_union)  NOMBRE_UNION, 
       case when b.ETL_ID is null then 'I' else 'U' end as TIPOREGTALEND
FROM adc400exp.vpdvfim TR LEFT OUTER JOIN TSALESFORCE.TACCOUNT b
ON TO_CHAR(TR.UNI_ON) = b.N_VENDEDOR
WHERE TR.red_pdv in  (1,3,4)
AND TO_DATE(TR.FEC_MOD,'DD/MM/YYYY') > TO_DATE('###REPLACE_BY_DATE###', 'DD/MM/YYYY HH24:MI:SS')
GROUP BY TR.uni_on, TR.nom_com_union, case when b.ETL_ID is null then 'I' else 'U' end
