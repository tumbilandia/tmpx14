INSERT INTO TACCOUNT
      (NAMEX,
       N_VENDEDOR,
       OWNERID,
       CREATEDDATE,
       CREATEDBYID,
       RECORDTYPEID,
       NOMBRE_UNION,
       DELETE_FLAG)
VALUES(:NOMBRE_UNION:,
       :N_VENDEDOR:,
       '00520000000otT7AAI',
        SYSDATE,
       '00520000000otT7AAI',
       (select Id
          from trecordtype
         where idcetelem='UNION'
           and rownum < 2),
        :NOMBRE_UNION:,
        'I');

UPDATE TACCOUNT
SET SYSTEMMODSTAMP = sysdate,
    NOMBRE_UNION= :NOMBRE_UNION:,
    OWNERID = '00520000000otT7AAI',
    Id = Case When Delete_Flag = 'Y'
          Then null
          Else Id
        End,
    DELETE_FLAG = Case When Delete_Flag= 'N'
                  then 'U'
                  else Delete_Flag
                  end
WHERE  N_VENDEDOR= :N_VENDEDOR:
