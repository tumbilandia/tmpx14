UPDATE TACCOUNT
SET SYSTEMMODSTAMP = sysdate,
MIX_CLASICO = :MIX_CLASICO:,
    DELETE_FLAG = Case When Delete_Flag= 'N' then 'U'
		     else Delete_Flag
                   end
WHERE  N_VENDEDOR = :N_VENDEDOR: AND RED IN ('1','3','4')
