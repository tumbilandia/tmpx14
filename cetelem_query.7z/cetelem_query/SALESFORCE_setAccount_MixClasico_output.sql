UPDATE TACCOUNT SET SYSTEMMODSTAMP = sysdate,
MIX_CLASICO = :MIX_CLASICO:,
         DELETE_FLAG =
    CASE
    WHEN Delete_Flag= 'N' THEN
    'U'
    ELSE Delete_Flag
    END
    WHERE N_VENDEDOR = :N_VENDEDOR:
        AND RED IN ('1','3','4')
