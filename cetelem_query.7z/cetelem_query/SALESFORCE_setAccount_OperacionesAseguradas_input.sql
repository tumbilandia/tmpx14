SELECT COUNT(*) OPERACIONESASEGURADAS,
        TO_CHAR(TR.NUM_VND) N_VENDEDOR, 
       case when b.ETL_ID is null then 'I' else 'U' end as TIPOREGTALEND
    FROM ADC400EXP.RECIFIMES TR INNER JOIN TSALESFORCE.TACCOUNT b
ON TO_CHAR(TR.NUM_VND) = b.N_VENDEDOR
    WHERE TR.RED IN (1,3,4)
        AND (TR.SEGURO<>'N'
        OR TR.SEGURO=NULL
        OR TR.SEGURO='0')
        AND (TR.ORIGEN='F')
        AND TO_DATE(TR.FCH_FINAN,'yyyy-mm-dd')  > TO_DATE('###REPLACE_BY_DATE###', 'DD/MM/YYYY HH24:MI:SS')
        GROUP BY TR.NUM_VND, case when b.ETL_ID is null then 'I' else 'U' end
