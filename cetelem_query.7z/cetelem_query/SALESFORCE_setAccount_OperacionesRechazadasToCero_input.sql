select to_char(N_VENDEDOR)
from V_PDV_A_0_DIARIO
