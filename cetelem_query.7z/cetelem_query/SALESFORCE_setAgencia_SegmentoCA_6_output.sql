UPDATE TAGENCIA
SET SYSTEMMODSTAMP = sysdate+1,
NOCAIDOS = :NOCAIDOS:,
DELETE_FLAG = Case When Delete_Flag= 'N' then 'U'
	else Delete_Flag end
WHERE  ID = :ID:
