UPDATE TAGENCIA
SET SYSTEMMODSTAMP = sysdate+1,
NOINACTIVOS = :NOINACTIVOS:,
DELETE_FLAG = Case When Delete_Flag= 'N' then 'U'
	else Delete_Flag end
WHERE  ID = :ID:
