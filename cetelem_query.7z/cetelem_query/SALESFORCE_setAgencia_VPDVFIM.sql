SELECT DISTINCT pd.AGEN  NAMEX, TO_CHAR(RED_PDV) RED, TO_CHAR(SOC) SOCIEDAD
FROM ADC400EXP.VPDVFIM pd
WHERE pd.red_pdv IN (1,3,4)

INSERT INTO TAGENCIA
      (
       OWNERID,
       NAMEX,
       CREATEDDATE,
       CREATEDBYID,
       RED,
       SOCIEDAD,
       DELETE_FLAG
      )
VALUES
      (
       '00520000000otT7AAI',
       :NAMEX:,
       SYSDATE+1,
       '00520000000otT7AAI',
       :RED:,
       :SOCIEDAD:,
       'I'
       )
UPDATE TAGENCIA
SET
       SYSTEMMODSTAMP = sysdate+1,
       RED = :RED:, SOCIEDAD= :SOCIEDAD:,
       DELETE_FLAG = Case When DELETE_FLAG= 'Y' then 'I'
                          When Delete_Flag= 'I' then 'I'
                          When Delete_Flag= 'N' then 'U'
                          else 'U'
             end,
       Id = Case When Delete_Flag = 'Y'
              Then null
              Else Id
            End
WHERE  NAMEX = :NAMEX: and RED = :RED: and SOCIEDAD = :SOCIEDAD:
