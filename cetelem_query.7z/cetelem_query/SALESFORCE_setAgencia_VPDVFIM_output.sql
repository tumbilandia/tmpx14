INSERT INTO TAGENCIA
      (
       OWNERID,
       NAMEX,
       CREATEDDATE,
       CREATEDBYID,
       RED,
       SOCIEDAD,
       DELETE_FLAG
      )
VALUES
      (
       '00520000000otT7AAI',
       :NAMEX:,
       SYSDATE,
       '00520000000otT7AAI',
       :RED:,
       :SOCIEDAD:,
       'I'
     );
     UPDATE TAGENCIA
     SET
            SYSTEMMODSTAMP = sysdate,
            RED = :RED:, SOCIEDAD= :SOCIEDAD:,
            DELETE_FLAG = Case When DELETE_FLAG= 'Y' then 'I'
                               When Delete_Flag= 'I' then 'I'
                               When Delete_Flag= 'N' then 'U'
                               else 'U'
                  end,
            Id = Case When Delete_Flag = 'Y'
                   Then null
                   Else Id
                 End
     WHERE  NAMEX = :NAMEX: and RED = :RED: and SOCIEDAD = :SOCIEDAD:
