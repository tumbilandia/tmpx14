UPDATE TAGENCIA
SET
       SYSTEMMODSTAMP = sysdate+1,
       RED = :RED:, SOCIEDAD= :SOCIEDAD:,
       DELETE_FLAG = Case When DELETE_FLAG= 'Y' then 'I'
                          When Delete_Flag= 'I' then 'I'
                          When Delete_Flag= 'N' then 'U'
                          else 'U'
             end,
       Id = Case When Delete_Flag = 'Y'
              Then null
              Else Id
            End
WHERE  NAMEX = :NAMEX: and RED = :RED: and SOCIEDAD = :SOCIEDAD:
