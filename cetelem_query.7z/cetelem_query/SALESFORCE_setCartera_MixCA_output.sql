UPDATE TCARTERA
SET SYSTEMMODSTAMP = sysdate+1,
MIXCLASICO = :MIXCLASICO:,
DELETE_FLAG = Case When Delete_Flag= 'N' then 'U'
	else Delete_Flag end
WHERE  NAMEX = :NAMEX: and red = :RED:
