UPDATE TCARTERA
SET NOINDECISOS = :NOINDECISOS:,
DELETE_FLAG = Case When Delete_Flag= 'N' then 'U'
	else Delete_Flag end,
	SYSTEMMODSTAMP = sysdate+1
WHERE  ID = :ID:
