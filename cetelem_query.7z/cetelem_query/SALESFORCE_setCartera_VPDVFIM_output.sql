INSERT INTO TCARTERA
      (OWNERID,
       NAMEX,
       CREATEDDATE,
       CREATEDBYID,
       RECORDTYPEID,
       RED,
       DESCRIPCION,
       AGENCIA,
       SOCIEDAD,
       DELETE_FLAG)
VALUES('00520000000otT7AAI',
       :NAMEX:,
       SYSDATE+1,
	   '00520000000otT7AAI',
       (SELECT Id
	      FROM TRECORDTYPE
	     WHERE SOBJECTTYPE = 'Cartera__c'
	      and idcetelem='DISTRIBUCION'
	      and rownum < 2),
       :RED:,
	   :NAMEX:,
       (select id
	      from tagencia TA
	     where TA.red = :RED:
		  and TA.namex = :AGENCIA:
		  and TA.SOCIEDAD = :SOCIEDAD:
		  and delete_flag not in ('Y','D')),
        :SOCIEDAD:,
        'I');
UPDATE TCARTERA
SET
    SYSTEMMODSTAMP = sysdate+1,
    RED = :RED:,
 -- ownerid = '00520000000otT7AAI',
    AGENCIA = (select id
	             from tagencia TA
			    where TA.red = :RED:
				 and TA.namex = :AGENCIA:
				 and TA.SOCIEDAD = :SOCIEDAD:
				 and delete_flag not in ('Y','D')),
	SOCIEDAD = :SOCIEDAD:,
    DELETE_FLAG = Case When DELETE_FLAG= 'Y' then 'I'
                       When Delete_Flag= 'I' then 'I'
                       When Delete_Flag= 'N' then 'U'
                       else 'U'
                   end,
    Id = Case When Delete_Flag = 'Y'
              Then null
              Else Id
            End
WHERE  NAMEX = :NAMEX:
 AND RED = :RED:
 AND SOCIEDAD = :SOCIEDAD: