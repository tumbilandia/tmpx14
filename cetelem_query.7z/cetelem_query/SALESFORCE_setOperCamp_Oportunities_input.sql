SELECT numvendedor,baremosuso baremo,PRODUCTO PRODUCTO,cod_gratuito,subproducto,SUM(totaloperaciones) totaloperaciones,SUM(totalfinanciadas) totalfinanciadas
FROM (
SELECT
      TO_CHAR(B.NOVENDEDOR)         NUMVENDEDOR,
      B.BAREMOSUSO,
      B.PRODUCTO,
      B.COD_GRATUITO     COD_GRATUITO,
      B.SUBPRODUCTO,
      COUNT(*)     TOTALOPERACIONES,
      SUM(B.AMOUNT)   TOTALFINANCIADAS,
                    b.CLOSEDATE
FROM TSALESFORCE.TOPPORTUNITY B
WHERE b.CLOSEDATE IS NOT NULL AND b.RED IN ('1','3','4') AND
b.stagename = (SELECT value FROM tsalesforce.RJ_REFERENCE WHERE object_name='OPPORTUNITY' AND idcetelem='F' AND ROWNUM <2)
AND      b.CLOSEDATE >= (SELECT fechainicio FROM tsalesforce.TOPERCAMP oper WHERE oper.numvendedor=b.NOVENDEDOR     AND
                                                                  oper.baremo=b.baremosuso           AND
                                                            oper.producto=b.PRODUCTO  AND
                                                            (oper.cod_gratuito=b.cod_gratuito OR b.cod_gratuito IS NULL)      AND (oper.subproducto=b.subproducto OR b.subproducto IS NULL)
AND ROWNUM <2)     AND b.CLOSEDATE <= (SELECT fechafin    FROM tsalesforce.TOPERCAMP oper WHERE oper.numvendedor=b.NOVENDEDOR     AND
                                                                   oper.baremo=b.baremosuso           AND
                                                            oper.producto=b.PRODUCTO  AND
                                                            (oper.cod_gratuito=b.cod_gratuito OR b.cod_gratuito IS NULL)      AND      (oper.subproducto=b.subproducto OR b.subproducto IS NULL)
AND ROWNUM <2)
GROUP BY B.NOVENDEDOR,B.PRODUCTO,B.BAREMOSUSO,b.CLOSEDATE , B.COD_GRATUITO, B.SUBPRODUCTO)
GROUP BY numvendedor,baremosuso,PRODUCTO,cod_gratuito,subproducto
