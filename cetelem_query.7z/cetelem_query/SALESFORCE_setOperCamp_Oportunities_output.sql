UPDATE TOPERCAMP
SET    SYSTEMMODSTAMP = sysdate+1,
       DELETE_FLAG = Case When DELETE_FLAG= 'Y' then 'I'
                                                       When Delete_Flag= 'I' then 'I'
                                                       When Delete_Flag= 'N' then 'U'
                                                       else 'U'
                       end,
       TOTALOPERACIONES = :TOTALOPERACIONES:,
       TOTALFINANCIADAS = :TOTALFINANCIADAS:
WHERE  NUMVENDEDOR = :NUMVENDEDOR:
AND    PRODUCTO = :PRODUCTO:
AND    BAREMO = :BAREMO:
AND   (  COD_GRATUITO = TRIM( :COD_GRATUITO:) OR COD_GRATUITO IS NULL
               OR     SUBPRODUCTO  = TRIM( :SUBPRODUCTO:)  OR SUBPRODUCTO IS NULL     )
AND Delete_Flag NOT IN ('Y','D')
