INSERT INTO TOPPORTUNITY
      (
       ACCOUNTID,
       NAMEX,
       N_CONTRATO_REAL,

       CLOSEDATE,

       OWNERID,
       CREATEDDATE,
       CREATEDBYID,
       LASTMODIFIEDDATE, LASTMODIFIEDBYID,   TIN,       DURACION_MESES,
       NUMERO_AUTORIZACION,SEGURO, PRODUCTO,APLAZAMIENTO,
       REFERENCIA_DE_ARCHIVO,
       BAREMOSUSO,
       SUBPRODUCTO,
       ALBARAN,    PRECIO_AL_CONTADO,
       IMPORTE_NETO,       ANNO_DE_FABRICACION,
       STAGENAME,
       FECHA_DE_ENTRADA,
       AMOUNT,
       DNI_CLIENTE_FINAL,
       NOMBRE_CLIENTE_FINAL,
       RED,COD_GRATUITO,
       COM_GRATUITO, NOVENDEDOR,     IMPDUR,       IMPDURTEG,
       RECORDTYPEID,
       MENSUALIDAD,
       DELETE_FLAG
       )
VALUES
      ((select id from taccount where n_vendedor = :ACCOUNTID: AND DELETE_FLAG NOT IN ('Y','D') and rownum <2),
       :NAMEX:,
       :N_CONTRATO_REAL:,
       :CLOSEDATE: +2/24,'00520000000otT7AAI',
       SYSDATE,'00520000000otT7AAI',
       SYSDATE,       '00520000000otT7AAI',
       :TIN:,
       :DURACION_MESES:,
    :NUMERO_AUTORIZACION:,
       :SEGURO:,
       :PRODUCTO:,
       :APLAZAMIENTO:,  :REFERENCIA_DE_ARCHIVO:,
       :BAREMOSUSO:,
       :SUBPRODUCTO:,
       :ALBARAN:,
       :PRECIO_AL_CONTADO:,
       :IMPORTE_NETO:,
       :ANNO_DE_FABRICACION:,
       (select value from tsalesforce.rj_reference where object_name='OPPORTUNITY' and field_name = 'STAGENAME' and idcetelem = :STAGENAME: and rownum < 2),
        :FECHA_DE_ENTRADA: +2/24,
        :AMOUNT:,     :DNI_CLIENTE_FINAL:,        :NOMBRE_CLIENTE_FINAL:,
        :RED:,
        :COD_GRATUITO:,
        :COM_GRATUITO:,
        :NOVENDEDOR:,
        :IMPDUR: ,
        :IMPDURTEG:,'012200000008eMnAAI',
     :MENSUALIDAD:,'I' );
UPDATE TOPPORTUNITY
SET   SYSTEMMODSTAMP = sysdate+1,
      ACCOUNTID = (select id from taccount where n_vendedor = :ACCOUNTID: AND DELETE_FLAG NOT IN ('Y','D') and rownum <2),
N_CONTRATO_REAL = :N_CONTRATO_REAL:,
CLOSEDATE = :CLOSEDATE: +2/24,CREATEDBYID      = '00520000000otT7AAI',
       LASTMODIFIEDBYID = '00520000000otT7AAI',
       SYSTEMMODSTAMP   = SYSDATE +3/24,
       TIN              = :TIN:,
       DURACION_MESES   = :DURACION_MESES:,
       NUMERO_AUTORIZACION = :NUMERO_AUTORIZACION:,     SEGURO           = :SEGURO:,
       PRODUCTO         = :PRODUCTO:,
       REFERENCIA_DE_ARCHIVO = :REFERENCIA_DE_ARCHIVO:,
       BAREMOSUSO       = :BAREMOSUSO:,
       SUBPRODUCTO      = :SUBPRODUCTO:,
       ALBARAN          = :ALBARAN:,
       PRECIO_AL_CONTADO = :PRECIO_AL_CONTADO:,
  IMPORTE_NETO     = :IMPORTE_NETO:,
       ANNO_DE_FABRICACION = :ANNO_DE_FABRICACION:,
       STAGENAME        = (select value from tsalesforce.rj_reference where object_name='OPPORTUNITY' and field_name = 'STAGENAME' and idcetelem = :STAGENAME: and rownum < 2),
       FECHA_DE_ENTRADA = :FECHA_DE_ENTRADA: +2/24,   AMOUNT = :AMOUNT:,
       DNI_CLIENTE_FINAL    = :DNI_CLIENTE_FINAL:,       NOMBRE_CLIENTE_FINAL = :NOMBRE_CLIENTE_FINAL:, COD_GRATUITO         = :COD_GRATUITO:,
       COM_GRATUITO         = :COM_GRATUITO:,
       NOVENDEDOR           = :NOVENDEDOR:,
       IMPDUR               = :IMPDUR:,
       IMPDURTEG            = :IMPDURTEG:,
       RECORDTYPEID         = '012200000008eMnAAI',
       MENSUALIDAD = :MENSUALIDAD:,
       delete_flag = Case When Delete_Flag= 'Y' then 'I'
                       When Delete_Flag= 'I' then 'I'
                       When Delete_Flag= 'N' then 'U'
                       else 'U'
          end,
       Id = Case When Delete_Flag = 'Y' Then null Else Id  End
WHERE NAMEX  = :NAMEX: AND
     ( STAGENAME <> (select value from tsalesforce.rj_reference where object_name='OPPORTUNITY' and field_name = 'STAGENAME' and idcetelem = :STAGENAME: and rownum < 2) OR
       NOVENDEDOR <> :NOVENDEDOR: OR
       FECHA_DE_ENTRADA <> :FECHA_DE_ENTRADA: +2/24 OR
       CLOSEDATE  <> :CLOSEDATE: +2/24 )
