INSERT INTO TRED
      (OWNERID,
       NAMEX,
       MIXCLASICO,
       RECIBIDOTARJETAACTUAL,
       RECIBIDOCLASICOACTUAL,
       FINANCIADOCLASICOACTUAL,
       NOFIDELIZADOS,
       NOPROPENSOS,
       NOINDECISOS,
       NOCAIDOS,
       NOINACTIVOS,
DELETE_FLAG)
VALUES
      ('00520000000otT7AAI',
       :NAMEX:,
       :MIXCLASICO:,
       :RECIBIDOTARJETAACTUAL:,
       :RECIBIDOCLASICOACTUAL:,
       :FINANCIADOCLASICOACTUAL:,
       :NOFIDELIZADOS:,
       :NOPROPENSOS:,
       :NOINDECISOS:,
       :NOCAIDOS:,
       :NOINACTIVOS:,
       'I');
UPDATE TRED
SET    SYSTEMMODSTAMP = sysdate+1,
       MIXCLASICO = :MIXCLASICO:,
       RECIBIDOTARJETAACTUAL = :RECIBIDOTARJETAACTUAL:,
       RECIBIDOCLASICOACTUAL = :RECIBIDOCLASICOACTUAL:,
       FINANCIADOCLASICOACTUAL = :FINANCIADOCLASICOACTUAL:,
       NOFIDELIZADOS = :NOFIDELIZADOS:,
       NOPROPENSOS = :NOPROPENSOS:,
       NOINDECISOS = :NOINDECISOS:,
       NOCAIDOS = :NOCAIDOS:,
       NOINACTIVOS = :NOINACTIVOS:,
DELETE_FLAG = Case When DELETE_FLAG= 'Y' then 'I'
                                                       When Delete_Flag= 'I' then 'I'
                                                       When Delete_Flag= 'N' then 'U'
                                                       else 'U'
                       end
WHERE  NAMEX = :NAMEX:
