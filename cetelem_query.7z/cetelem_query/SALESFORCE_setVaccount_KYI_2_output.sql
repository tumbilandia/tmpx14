UPDATE TACCOUNT
SET SYSTEMMODSTAMP = sysdate,
ID_VENDEDOR = :ID_VENDEDOR:,
WEB = :WEB:,
DELETE_FLAG = case when lower(id) not like 'x-%'
then 'U' else delete_flag end
WHERE  N_VENDEDOR = :N_VENDEDOR:
