Copy in install directory run only tcrun.exe or tcrun64.exe

or copy wincmd.key in install directory