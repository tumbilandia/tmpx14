/*
 * decompile.h
 *
 *  Created on: Jan 23, 2011
 *      Author: iubi
 */

#ifndef DECOMPILE_H_

	#define DECOMPILE_H_

	char* DecompileJavaClass(WCHAR* FileToLoad);
	BOOL ExecuteCommand(WCHAR* cmd, const WCHAR* workingDir);

#endif /* DECOMPILE_H_ */
