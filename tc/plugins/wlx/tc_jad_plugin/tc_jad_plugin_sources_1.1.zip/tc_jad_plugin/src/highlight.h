/*
 * highlight.h
 *
 *  Created on: Jan 23, 2011
 *      Author: iubi
 */

#ifndef HIGHLIGHT_H_

	#define HIGHLIGHT_H_

	void InitHighlightGlobals();
	void HighlightWindowText(HWND hwnd);

	void InsertTextLine(HWND hwnd, const char *szTextIn, CHARFORMAT2 cf);
	void AddTextLine(HWND hwnd, const char *szTextIn, CHARFORMAT2 cf);

	void AddSignature(HWND hwnd, int decompileTime, int highlightingTime, int totalLoadTime);

#endif /* HIGHLIGHT_H_ */
