<#

2024-02-11 06:35:47 

Rename-Item -Path "C:\logs\robocopy.log" -NewName "robocopy-$(Get-Date -F yyyy.MM.dd)$($_.Extension).log"
#>

$src = 'd:\_dev\sopra\projects\airbus\01-OpenShift\docs\installation'
$dst = 'd:\temp\z'
$file_new = '-robocopy-new.log'
$file_all = '-robocopy.log'
$log = $dst + '\' + $(Get-Date -F yyyy.MM.dd) + $file_new
$opt = @('/E', '/MAXAGE:3', '/L', '/MAX:3145728', '/TEE', '/NDL', '/TS')
$hst = $dst + '\_hist' 

# Check if the destination folder exists, if not, create it
if (-not (Test-Path -Path $hst -PathType Container)) {
    New-Item -Path $hst -ItemType Directory
}

# Move all .log files from the source folder to the destination folder
Get-ChildItem -Path $dst -Filter *.log | Move-Item -Destination $hst -Force

# 00. Show only new folders/files and save to log
$cmd = @($src, $dst) + $opt
& 'robocopy.exe' $cmd /log:$log

# 01. All folders/filses and save to log
$log = $dst + '\' + $(Get-Date -F yyyy.MM.dd) + $file_all
$opt = @('/S', '/MAXAGE:3', '/MAX:3145728', '/TEE', '/NDL', '/TS')
$cmd = @($src, $dst) + $opt
& 'robocopy.exe' $cmd /log:$log
